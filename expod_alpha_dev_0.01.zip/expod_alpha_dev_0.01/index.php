// Expod Alpha Development 0.01 
// Building the Basic Framework for this Open Source Project while Learning
// Keeping it a Zero Release until Expod Alpha Major Release 1.0  

// https://github.com/BrandonKastningSeattle/Expod
// https://github.com/BrandonKastningSeattle/Expod/blob/main/expod_alpha_dev_0.01.zip

// "Expod" means "EXODUS" in Latin... 
// "EXODUS" means "A Mass Departure of People"

// Learning Mark-up/PHP-Lang/GitHub

// Sources:

// For Dummies - PHP, MySQL & JavaScript All-In-One For Dummies 2nd Edition (Blum, 2025).
// O'Reilly - Learning PHP, MySQL & JavaScript (Nixon, 2025).

// Date Updated: 12/04/2025
// Time Updated: 11:17 AM

<?php
    $ElijahForgeAuthIn = false;

    if ($ElijahForgeAuthIn) {
        echo "<!DOCTYPE html>";
        echo "<html lang='en'>";
        echo "<head>";
        echo "<meta charset='UTF-8'>";
        echo "<meta name='description' content='Expod! (Lat.) | Exodus USA is being developed to become an out of the box Open Source Resource to American Citizens to Empower American Citizens! Expod! (Lat.) | Exodus USA will always be Free and Open Source, No matter how large the codebase becomes!'>";
        echo "<meta name='generator' content='Expod! (Lat.) | Exodus USA - Open Source American Citizen Empowerment'>";
        echo "<title>Elijah Forge | Seattle, WA | Authenticated & Logged In!</title>";
        echo "</head>";
        echo "<body>";
        echo "<h1>Welcome to Elijah Forge Seattle, WA!</h1>";
        echo "<p>Logged In Paragraph (p-tag content)...</p>";
        echo "</body>";
        echo "</html>";
    } else {
        echo "<!DOCTYPE html>";
        echo "<html lang='en'>";
        echo "<head>";
        echo "<meta charset='UTF-8'>";
        echo "<meta name='description' content='Expod! (Lat.) | Exodus USA is being developed to become an out of the box Open Source Resource to American Citizens to Empower American Citizens! Expod! (Lat.) | Exodus USA will always be Free and Open Source, No matter how large the codebase becomes!'>";
        echo "<meta name='generator' content='Expod! (Lat.) | Exodus USA - Open Source American Citizen Empowerment'>";
        echo "<title>Elijah Forge | Seattle, WA | Non-Authenticated & Logged Out!</title>";
        echo "</head>";
        echo "<body>";
        echo "<h1>Welcome to Elijah Forge Seattle, WA!</h1>";
        echo "<p>Logged Out Paragraph (p-tag content)...</p>";
        echo "</body>";
        echo "</html>";
    }
?>

