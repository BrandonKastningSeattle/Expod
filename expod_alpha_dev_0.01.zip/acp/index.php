<?php
    $ElijahForgeAuthIn = false;

    if ($ElijahForgeAuthIn) {
        echo "<!DOCTYPE html>";
        echo "<html lang='en'>";
        echo "<head>";
        echo "<meta charset='UTF-8'>";
        echo "<meta name='description' content='Expod! (Lat.) | Exodus USA is being developed to become an out of the box Open Source Resource to American Citizens to Empower American Citizens! Expod! (Lat.) | Exodus USA will always be Free and Open Source, No matter how large the codebase becomes! (AdminCP/acp)'>";
        echo "<meta name='generator' content='Expod! (Lat.) | Exodus USA - Open Source American Citizen Empowerment'>";
        echo "<title>Elijah Forge | Seattle, WA | Authenticated & Logged In! (AdminCP/acp)</title>";
        echo "</head>";
        echo "<body>";
        echo "<h1>Welcome to Elijah Forge Seattle, WA! (AdminCP/acp)</h1>";
        echo "<p>Logged In Paragraph (p-tag content)...</p>";
        echo "</body>";
        echo "</html>";
    } else {
        echo "<!DOCTYPE html>";
        echo "<html lang='en'>";
        echo "<head>";
        echo "<meta charset='UTF-8'>";
        echo "<meta name='description' content='Expod! (Lat.) | Exodus USA is being developed to become an out of the box Open Source Resource to American Citizens to Empower American Citizens! Expod! (Lat.) | Exodus USA will always be Free and Open Source, No matter how large the codebase becomes! (AdminCP/acp)'>";
        echo "<meta name='generator' content='Expod! (Lat.) | Exodus USA - Open Source American Citizen Empowerment'>";
        echo "<title>Elijah Forge | Seattle, WA | Non-Authenticated & Logged Out! (AdminCP/acp)</title>";
        echo "</head>";
        echo "<body>";
        echo "<h1>Welcome to Elijah Forge Seattle, WA! (AdminCP/acp)</h1>";
        echo "<p>Logged Out Paragraph (p-tag content)...</p>";
        echo "</body>";
        echo "</html>";
    }
?>

